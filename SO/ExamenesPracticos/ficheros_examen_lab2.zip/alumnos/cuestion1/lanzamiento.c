#include <stdio.h>
#include <getopt.h>
#include <stdlib.h>

/**
 * Launchs a bash command creating a new
 * child process that execs /bin/bash.
 * 
 * The function returns the pid of the 
 * newly created process, and does not wait
 * for the process to complete. 
*/
pid_t run_command(const char* command){
    pid_t pid = -1;

    /* To be completed ... */

    return pid;
}

#define MAX_COMMANDS 20
#define MAX_CHARS_LINE 128

int main(int argc, char* argv[]){
	int opt;

	while ((opt = getopt(argc, argv, "hx:")) != -1)
	{
		switch (opt)
		{
		case 'h':
            printf("Usage: %s [ -x <command> | -s <script> | -b]\n", argv[0]);
			break;
        /* To be completed ... */

		default:
			exit(2);
		}
	}

    /* To be completed ... */

    return 0;
}